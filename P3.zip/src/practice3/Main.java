package practice3;

import view.Grafics;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Controller ctrl = new Controller();
		@SuppressWarnings("unused")
		Grafics graph = new Grafics(ctrl);
	}

}
