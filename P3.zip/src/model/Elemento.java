package model;

public enum Elemento {
	Suma, Resta, Multiplicacion, Division, SQRT, LOG, A;
	
}